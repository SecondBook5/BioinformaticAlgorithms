// PatternCountTest.java
package edu.yu.bioinfo.test;

import org.junit.*;
import static org.junit.Assert.*;

import edu.yu.bioinfo.PatternCount;

public class PatternCountTest {

    @Test
    public void testPatternCountWithRandomTextAndPattern() {
        String text = "AGCTAGCTAGCTAGCT";
        String pattern = "GCT";
        int count = PatternCount.patternCount(text, pattern);
        assertEquals(4, count);
    }

    @Test
    public void testPatternCountWithSingleCharacterPattern() {
        String text = "AAATTTGGGCCCAAATTT";
        String pattern = "A";
        int count = PatternCount.patternCount(text, pattern);
        assertEquals(6, count);
    }

    @Test
    public void testPatternCountWithPatternLongerThanText() {
        String text = "ATGC";
        String pattern = "ATGCGC";
        int count = PatternCount.patternCount(text, pattern);
        assertEquals(0, count);
    }

    @Test
    public void testPatternCountWithLargeTextAndPattern() {
        String text = "ACGT" + "ACGTACGTACGTACGT".repeat(1000) + "ACGT";
        String pattern = "ACGT";
        int count = PatternCount.patternCount(text, pattern);
        assertEquals(4002, count);
    }
    
    @Test
    public void testPatternCountWithValidInput() {
        // Test case with valid input
        String text = "ACGTTTCACGTTTTACGG";
        String pattern = "ACGT";
        int expectedCount = 2; // The pattern "ACGT" appears three times in the text
        int actualCount = PatternCount.patternCount(text, pattern);
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testPatternCountWithNoMatch() {
        // Test case where the pattern has no match in the text
        String text = "ACGTTTCACGTTTTACGG";
        String pattern = "AAAA";
        int expectedCount = 0; // The pattern "AAAA" does not appear in the text
        int actualCount = PatternCount.patternCount(text, pattern);
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testPatternCountWithEmptyText() {
        // Test case with an empty text
        String text = "";
        String pattern = "ACGT";
        int expectedCount = 0; // The pattern cannot appear in an empty text
        int actualCount = PatternCount.patternCount(text, pattern);
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testPatternCountWithEmptyPattern() {
        // Test case with an empty pattern
        String text = "ACGTTTCACGTTTTACGG";
        String pattern = "";
        int expectedCount = 0; // An empty pattern has no occurrences
        int actualCount = PatternCount.patternCount(text, pattern);
        assertEquals(expectedCount, actualCount);
    }
}
